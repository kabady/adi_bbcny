/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 15);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
module.exports = function (useSourceMap) {
	var list = [];

	// return the list of modules as css string
	list.toString = function toString() {
		return this.map(function (item) {
			var content = cssWithMappingToString(item, useSourceMap);
			if (item[2]) {
				return "@media " + item[2] + "{" + content + "}";
			} else {
				return content;
			}
		}).join("");
	};

	// import a list of modules into the list
	list.i = function (modules, mediaQuery) {
		if (typeof modules === "string") modules = [[null, modules, ""]];
		var alreadyImportedModules = {};
		for (var i = 0; i < this.length; i++) {
			var id = this[i][0];
			if (typeof id === "number") alreadyImportedModules[id] = true;
		}
		for (i = 0; i < modules.length; i++) {
			var item = modules[i];
			// skip already imported module
			// this implementation is not 100% perfect for weird media query combinations
			//  when a module is imported multiple times with different media queries.
			//  I hope this will never occur (Hey this way we have smaller bundles)
			if (typeof item[0] !== "number" || !alreadyImportedModules[item[0]]) {
				if (mediaQuery && !item[2]) {
					item[2] = mediaQuery;
				} else if (mediaQuery) {
					item[2] = "(" + item[2] + ") and (" + mediaQuery + ")";
				}
				list.push(item);
			}
		}
	};
	return list;
};

function cssWithMappingToString(item, useSourceMap) {
	var content = item[1] || '';
	var cssMapping = item[3];
	if (!cssMapping) {
		return content;
	}

	if (useSourceMap && typeof btoa === 'function') {
		var sourceMapping = toComment(cssMapping);
		var sourceURLs = cssMapping.sources.map(function (source) {
			return '/*# sourceURL=' + cssMapping.sourceRoot + source + ' */';
		});

		return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
	}

	return [content].join('\n');
}

// Adapted from convert-source-map (MIT)
function toComment(sourceMap) {
	// eslint-disable-next-line no-undef
	var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
	var data = 'sourceMappingURL=data:application/json;charset=utf-8;base64,' + base64;

	return '/*# ' + data + ' */';
}

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/
var stylesInDom = {},
	memoize = function(fn) {
		var memo;
		return function () {
			if (typeof memo === "undefined") memo = fn.apply(this, arguments);
			return memo;
		};
	},
	isOldIE = memoize(function() {
		// Test for IE <= 9 as proposed by Browserhacks
		// @see http://browserhacks.com/#hack-e71d8692f65334173fee715c222cb805
		// Tests for existence of standard globals is to allow style-loader 
		// to operate correctly into non-standard environments
		// @see https://github.com/webpack-contrib/style-loader/issues/177
		return window && document && document.all && !window.atob;
	}),
	getElement = (function(fn) {
		var memo = {};
		return function(selector) {
			if (typeof memo[selector] === "undefined") {
				memo[selector] = fn.call(this, selector);
			}
			return memo[selector]
		};
	})(function (styleTarget) {
		return document.querySelector(styleTarget)
	}),
	singletonElement = null,
	singletonCounter = 0,
	styleElementsInsertedAtTop = [],
	fixUrls = __webpack_require__(3);

module.exports = function(list, options) {
	if(typeof DEBUG !== "undefined" && DEBUG) {
		if(typeof document !== "object") throw new Error("The style-loader cannot be used in a non-browser environment");
	}

	options = options || {};
	options.attrs = typeof options.attrs === "object" ? options.attrs : {};

	// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
	// tags it will allow on a page
	if (typeof options.singleton === "undefined") options.singleton = isOldIE();

	// By default, add <style> tags to the <head> element
	if (typeof options.insertInto === "undefined") options.insertInto = "head";

	// By default, add <style> tags to the bottom of the target
	if (typeof options.insertAt === "undefined") options.insertAt = "bottom";

	var styles = listToStyles(list);
	addStylesToDom(styles, options);

	return function update(newList) {
		var mayRemove = [];
		for(var i = 0; i < styles.length; i++) {
			var item = styles[i];
			var domStyle = stylesInDom[item.id];
			domStyle.refs--;
			mayRemove.push(domStyle);
		}
		if(newList) {
			var newStyles = listToStyles(newList);
			addStylesToDom(newStyles, options);
		}
		for(var i = 0; i < mayRemove.length; i++) {
			var domStyle = mayRemove[i];
			if(domStyle.refs === 0) {
				for(var j = 0; j < domStyle.parts.length; j++)
					domStyle.parts[j]();
				delete stylesInDom[domStyle.id];
			}
		}
	};
};

function addStylesToDom(styles, options) {
	for(var i = 0; i < styles.length; i++) {
		var item = styles[i];
		var domStyle = stylesInDom[item.id];
		if(domStyle) {
			domStyle.refs++;
			for(var j = 0; j < domStyle.parts.length; j++) {
				domStyle.parts[j](item.parts[j]);
			}
			for(; j < item.parts.length; j++) {
				domStyle.parts.push(addStyle(item.parts[j], options));
			}
		} else {
			var parts = [];
			for(var j = 0; j < item.parts.length; j++) {
				parts.push(addStyle(item.parts[j], options));
			}
			stylesInDom[item.id] = {id: item.id, refs: 1, parts: parts};
		}
	}
}

function listToStyles(list) {
	var styles = [];
	var newStyles = {};
	for(var i = 0; i < list.length; i++) {
		var item = list[i];
		var id = item[0];
		var css = item[1];
		var media = item[2];
		var sourceMap = item[3];
		var part = {css: css, media: media, sourceMap: sourceMap};
		if(!newStyles[id])
			styles.push(newStyles[id] = {id: id, parts: [part]});
		else
			newStyles[id].parts.push(part);
	}
	return styles;
}

function insertStyleElement(options, styleElement) {
	var styleTarget = getElement(options.insertInto)
	if (!styleTarget) {
		throw new Error("Couldn't find a style target. This probably means that the value for the 'insertInto' parameter is invalid.");
	}
	var lastStyleElementInsertedAtTop = styleElementsInsertedAtTop[styleElementsInsertedAtTop.length - 1];
	if (options.insertAt === "top") {
		if(!lastStyleElementInsertedAtTop) {
			styleTarget.insertBefore(styleElement, styleTarget.firstChild);
		} else if(lastStyleElementInsertedAtTop.nextSibling) {
			styleTarget.insertBefore(styleElement, lastStyleElementInsertedAtTop.nextSibling);
		} else {
			styleTarget.appendChild(styleElement);
		}
		styleElementsInsertedAtTop.push(styleElement);
	} else if (options.insertAt === "bottom") {
		styleTarget.appendChild(styleElement);
	} else {
		throw new Error("Invalid value for parameter 'insertAt'. Must be 'top' or 'bottom'.");
	}
}

function removeStyleElement(styleElement) {
	styleElement.parentNode.removeChild(styleElement);
	var idx = styleElementsInsertedAtTop.indexOf(styleElement);
	if(idx >= 0) {
		styleElementsInsertedAtTop.splice(idx, 1);
	}
}

function createStyleElement(options) {
	var styleElement = document.createElement("style");
	options.attrs.type = "text/css";

	attachTagAttrs(styleElement, options.attrs);
	insertStyleElement(options, styleElement);
	return styleElement;
}

function createLinkElement(options) {
	var linkElement = document.createElement("link");
	options.attrs.type = "text/css";
	options.attrs.rel = "stylesheet";

	attachTagAttrs(linkElement, options.attrs);
	insertStyleElement(options, linkElement);
	return linkElement;
}

function attachTagAttrs(element, attrs) {
	Object.keys(attrs).forEach(function (key) {
		element.setAttribute(key, attrs[key]);
	});
}

function addStyle(obj, options) {
	var styleElement, update, remove;

	if (options.singleton) {
		var styleIndex = singletonCounter++;
		styleElement = singletonElement || (singletonElement = createStyleElement(options));
		update = applyToSingletonTag.bind(null, styleElement, styleIndex, false);
		remove = applyToSingletonTag.bind(null, styleElement, styleIndex, true);
	} else if(obj.sourceMap &&
		typeof URL === "function" &&
		typeof URL.createObjectURL === "function" &&
		typeof URL.revokeObjectURL === "function" &&
		typeof Blob === "function" &&
		typeof btoa === "function") {
		styleElement = createLinkElement(options);
		update = updateLink.bind(null, styleElement, options);
		remove = function() {
			removeStyleElement(styleElement);
			if(styleElement.href)
				URL.revokeObjectURL(styleElement.href);
		};
	} else {
		styleElement = createStyleElement(options);
		update = applyToTag.bind(null, styleElement);
		remove = function() {
			removeStyleElement(styleElement);
		};
	}

	update(obj);

	return function updateStyle(newObj) {
		if(newObj) {
			if(newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap)
				return;
			update(obj = newObj);
		} else {
			remove();
		}
	};
}

var replaceText = (function () {
	var textStore = [];

	return function (index, replacement) {
		textStore[index] = replacement;
		return textStore.filter(Boolean).join('\n');
	};
})();

function applyToSingletonTag(styleElement, index, remove, obj) {
	var css = remove ? "" : obj.css;

	if (styleElement.styleSheet) {
		styleElement.styleSheet.cssText = replaceText(index, css);
	} else {
		var cssNode = document.createTextNode(css);
		var childNodes = styleElement.childNodes;
		if (childNodes[index]) styleElement.removeChild(childNodes[index]);
		if (childNodes.length) {
			styleElement.insertBefore(cssNode, childNodes[index]);
		} else {
			styleElement.appendChild(cssNode);
		}
	}
}

function applyToTag(styleElement, obj) {
	var css = obj.css;
	var media = obj.media;

	if(media) {
		styleElement.setAttribute("media", media)
	}

	if(styleElement.styleSheet) {
		styleElement.styleSheet.cssText = css;
	} else {
		while(styleElement.firstChild) {
			styleElement.removeChild(styleElement.firstChild);
		}
		styleElement.appendChild(document.createTextNode(css));
	}
}

function updateLink(linkElement, options, obj) {
	var css = obj.css;
	var sourceMap = obj.sourceMap;

	/* If convertToAbsoluteUrls isn't defined, but sourcemaps are enabled
	and there is no publicPath defined then lets turn convertToAbsoluteUrls
	on by default.  Otherwise default to the convertToAbsoluteUrls option
	directly
	*/
	var autoFixUrls = options.convertToAbsoluteUrls === undefined && sourceMap;

	if (options.convertToAbsoluteUrls || autoFixUrls){
		css = fixUrls(css);
	}

	if(sourceMap) {
		// http://stackoverflow.com/a/26603875
		css += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + " */";
	}

	var blob = new Blob([css], { type: "text/css" });

	var oldSrc = linkElement.href;

	linkElement.href = URL.createObjectURL(blob);

	if(oldSrc)
		URL.revokeObjectURL(oldSrc);
}


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(4);
if(typeof content === 'string') content = [[module.i, content, '']];
// add the styles to the DOM
var update = __webpack_require__(1)(content, {});
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/postcss-loader/index.js!../../node_modules/sass-loader/lib/loader.js!./style.scss", function() {
			var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/postcss-loader/index.js!../../node_modules/sass-loader/lib/loader.js!./style.scss");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * When source maps are enabled, `style-loader` uses a link element with a data-uri to
 * embed the css on the page. This breaks all relative urls because now they are relative to a
 * bundle instead of the current page.
 *
 * One solution is to only use full urls, but that may be impossible.
 *
 * Instead, this function "fixes" the relative urls to be absolute according to the current page location.
 *
 * A rudimentary test suite is located at `test/fixUrls.js` and can be run via the `npm test` command.
 *
 */

module.exports = function (css) {
	// get current location
	var location = typeof window !== "undefined" && window.location;

	if (!location) {
		throw new Error("fixUrls requires window.location");
	}

	// blank or null?
	if (!css || typeof css !== "string") {
		return css;
	}

	var baseUrl = location.protocol + "//" + location.host;
	var currentDir = baseUrl + location.pathname.replace(/\/[^\/]*$/, "/");

	// convert each url(...)
	/*
 This regular expression is just a way to recursively match brackets within
 a string.
 	 /url\s*\(  = Match on the word "url" with any whitespace after it and then a parens
    (  = Start a capturing group
      (?:  = Start a non-capturing group
          [^)(]  = Match anything that isn't a parentheses
          |  = OR
          \(  = Match a start parentheses
              (?:  = Start another non-capturing groups
                  [^)(]+  = Match anything that isn't a parentheses
                  |  = OR
                  \(  = Match a start parentheses
                      [^)(]*  = Match anything that isn't a parentheses
                  \)  = Match a end parentheses
              )  = End Group
              *\) = Match anything and then a close parens
          )  = Close non-capturing group
          *  = Match anything
       )  = Close capturing group
  \)  = Match a close parens
 	 /gi  = Get all matches, not the first.  Be case insensitive.
  */
	var fixedCss = css.replace(/url\s*\(((?:[^)(]|\((?:[^)(]+|\([^)(]*\))*\))*)\)/gi, function (fullMatch, origUrl) {
		// strip quotes (if they exist)
		var unquotedOrigUrl = origUrl.trim().replace(/^"(.*)"$/, function (o, $1) {
			return $1;
		}).replace(/^'(.*)'$/, function (o, $1) {
			return $1;
		});

		// already a full url? no change
		if (/^(#|data:|http:\/\/|https:\/\/|file:\/\/\/)/i.test(unquotedOrigUrl)) {
			return fullMatch;
		}

		// convert the url to a full url
		var newUrl;

		if (unquotedOrigUrl.indexOf("//") === 0) {
			//TODO: should we add protocol?
			newUrl = unquotedOrigUrl;
		} else if (unquotedOrigUrl.indexOf("/") === 0) {
			// path should be relative to the base url
			newUrl = baseUrl + unquotedOrigUrl; // already starts with '/'
		} else {
			// path should be relative to current directory
			newUrl = currentDir + unquotedOrigUrl.replace(/^\.\//, ""); // Strip leading './'
		}

		// send back the fixed url(...)
		return "url(" + JSON.stringify(newUrl) + ")";
	});

	// send back the fixed css
	return fixedCss;
};

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)(undefined);
// imports


// module
exports.push([module.i, ".pointer-events-none {\n  pointer-events: none; }\n", ""]);

// exports


/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = "<div class=\"pc-wrapper\">\n  <div class=\"part-1\">\n    <img src=\"" + __webpack_require__(17) + "\" alt=\"\">\n  </div>\n  <div class=\"part-2\">\n    <img class=\"op\" src=\"" + __webpack_require__(18) + "\" alt=\"\">\n    <video controls=\"controls\" src=\"http://minisite-d.hupucdn.com/ADIDAS_MV_1222_W_LYRIC_1080.mp4\"></video>\n  </div>\n  <div class=\"part-3\">\n      <img src=\"" + __webpack_require__(19) + "\" alt=\"\">\n    <div class=\"action-ajax-click\"></div>\n    <div class=\"action-rule-click\"></div>\n  </div>\n</div>\n<div class=\"rule-float\">\n  <div class=\"float-wrapper\">\n    <div class=\"icon-close\"></div>\n    <div class=\"swiper-container\">\n      <div class=\"swiper-wrapper\">\n        <h3>adiCLUB会员规则</h3>\n        <h6>1. 目的 </h6>\n        <p>欢迎您成为adiCLUB会员。本adiCLUB会员规则（以下简称本“规则”）的目的在于明确界定您注册成为adiCLUB会员时的条件、规则以及您在使用由阿迪达斯体育（中国）有限公司（以下简称“阿迪达斯”）提供的会员服务时双方的权利、义务和责任。 </p>\n        <p>您在申请注册成为adiClub会员之前，请认真阅读本规则和本规则提及或引述的条款、条件和规则，尤其是黑体字和加下划线的条款，这些条款含有与您的权利义务有关的重要内容以及可能对您适用的限制及除外规定。当您在adiClub申请注册流程中签字或点击同意本规则后，即表示您已充分阅读、理解并接受本规则的全部内容。若您不同意本规则或其中任何一部分，请立即停止申请注册流程。</p>\n        <h6>2. 定义</h6>\n        <p>2-1. “会员资格持有人”或“会员”指申请adiCLUB会员资格、提供其个人信息、完成申请程序并接受本规则进而成为adiCLUB注册会员的个人。</p>\n        <p>2-2. “会员服务”指由阿迪达斯向会员提供的服务，包括管理会员先前的消费记录和提供与商品、消费相关的各种信息。</p>\n        <p>2-3. “指定网站”指adidas.com官网、adiclub.adidas.com.cn（包括其电脑终端和/或手机终端可访问的网站及相关移动应用）以及其他由阿迪达斯指定的与阿迪达斯一起提供会员服务的网站。会员可以在 adidas.com 官网或adiCLUB客服中心 （4008801515）获得经确认和更新的提供会员服务的指定网站名单。</p>\n        <p>2-4. “指定店铺”指由阿迪达斯经营的阿迪达斯自营店铺、由阿迪达斯不时指定的经销商店铺和其他由阿迪达斯指定的与阿迪达斯一起提供会员服务的店铺。会员可以在adidas.com官网或adiCLUB客服中心（4008801515）获得经确认和更新的提供会员服务的指定店铺名单。</p>\n        <p>2-5. “中国”指中华人民共和国大陆地区，为提供会员服务之目的， 不包括香港、澳门和台湾。</p>\n        <h6>3. 会员服务简介 </h6>\n        <p>3-1. 您需完成本规则规定的正确的会员申请注册流程，方能成为会员并享受阿迪达斯提供的会员服务。</p>\n        <p>3-2. 在成为会员后，您在指定网站使用注册手机号登陆并且消费可获得积分；或者在指定店铺消费时，出示手机号、会员号及个人姓名等信息消费亦可以获得积分。阿迪达斯的部分商品不适用积分规则（具体见本规则第7条“会员积分、优惠券的使用及限制”）。 </p>\n        <h6>4. 规则的效力和变更 </h6>\n        <p>4-1. 本规则自您于指定网站、阿迪达斯官方微信平台或指定店铺填写并提交会员资格申请时对您生效。</p>\n        <p>4-2. 阿迪达斯可能不时对本规则进行变更。若阿迪达斯变更本规则的，阿迪达斯将通过a) 电子邮件；b)信件；c)指定网站或者d)指定店铺发布通知等方式告知会员。</p>\n        <p>4-3. 任何对本规则的变更将于通知之日起30日后（或通知所载之生效日）生效。请您定期查阅以及时了解有关变更。如您对变更事项不同意的，您应当于变更事项生效之日起停止使用会员服务，变更事项对您不产生效力 。如您在变更事项生效后继续使用会员服务，即表示您完全接受这些变更。</p>\n        <p>4-4. 若您通过指定网站注册成会员或使用会员服务的，除了本规则外，您还同意遵守指定网站所有相关的条款、条件和规则。</p>\n        <h6>5. 会员注册 </h6>\n        <p>5-1. 为成为注册会员，您必须通过指定网站或阿迪达斯官方微信平台或在指定店铺提交会员资格申请。新会员在提交申请之后需通过指定网站验证手机号并确认全部所必需的个人信息后才能享受全部会员权益。</p>\n        <p>5-2. 会员资格在任何时候不得转让，也不得用于其他目的，如抵押。会员对违反本条规定造成的后果负全责。</p>\n        <h6>6. 会员资格及限制 </h6>\n        <p>6-1. 除非会员要求退会并提交退会申请，会员资格永久有效。但特定会员权益为不同等级会员在相关有效期内分别享有。</p>\n        <p>• 会员等级： </p>\n        <p>新标会员：在指定网站、阿迪达斯官方微信平台或指定店铺注册，填写提交完整会员资料，并阅读、接受本规则，即可成为新标会员。</p>\n        <p>铜牌会员：在指定网站或者指定店铺一次购物实际支付满1,000元（并无退货情况），填写、提交会员资格申请表，并阅读、接受本规则的，即可成为铜牌会员。新标会员12个月内在指定网站或者指定店铺累计支付金额达到1,000元（并无退货情况），即可自动升级为铜牌会员。</p>\n        <p>银座会员：在指定网站或者指定店铺一次购物实际支付满4,000元（并无退货情况），填写、提交会员资格申请表，并阅读、接受本规则的，即可成为银座会员。新标会员/铜牌会员12个月内在指定网站或者指定店铺累计支付金额达到4,000元（并无退货情况），即可自动升级为银座会员。</p>\n        <p>金尊会员：在指定网站或者指定店铺一次购物满8,000元（并无退货情况），填写、提交会员资格申请表，并阅读、接受本规则的，即可成为金尊会员。新标会员/铜牌会员/银座会员12个月内在指定网站或者指定店铺累计支付金额达到8,000元（并无退货情况），即可自动升级为金尊会员。</p>\n        <p>• 不同等级会员有效期： </p>\n        <p>铜牌会员/银座会员/金尊会员有效期为12个月。新入会的铜牌会员/银座会员/金尊会员，从入会当月起至第12个月的最后一日到期；升级成为铜牌会员/银座会员/金尊会员的，从升级之日起至第12个月的最后一日到期。</p>\n        <p>新标会员无会员有效期限制。</p>\n        <p>• 续会及限制： </p>\n        <p>• 铜牌会员续会：会员有效期内在指定网站或者指定店铺购物累计实际支付满1,000元（并无退货情况），即可续会；从续会当日起至第12个月的最后一日到期有效；</p>\n        <p>• 银座会员续会：会员有效期内在指定网站或者指定店铺购物累计实际支付满4,000元，即可续会；从续会当日起至第12个月的最后一日到期有效；银座会员若在会员有效期内在指定网站、指定店铺购物累计实际支付满1,000元但未满4,000元的，则自动降级为铜牌会员。</p>\n        <p>• 金尊会员续会：会员有效期内在指定网站或者指定店铺购物累计实际支付满8,000元，即可续会；从续会当日起至第12个月的最后一日到期有效；金尊会员若在会员有效期内在指定网站、指定店铺购物累计实际支付满4,000元但未满8,000元的，则自动降级为银座会员。</p>\n        <p>• 铜牌会员/银座会员/金尊会员在会员有效期内在指定网站或者指定店铺购物累计实际支付未满1,000元，则自动降级为新标会员。</p>\n        <h6>7. 会员积分、优惠券的使用及限制 </h6>\n        <p>7-1. 积分</p>\n        <p>&nbsp;&nbsp;(1) 会员在指定网站或者指定店铺购物通过现金、银行卡或网上支付等方式实际支付金额的100％计为积分（1人民币＝1个积分）。例如，如果会员实际支付人民币500元，可获得500点积分。</p>\n        <p>&nbsp;&nbsp;(2) 现金折扣及以优惠券、折扣券抵扣的金额部分不计入积分。</p>\n        <p>&nbsp;&nbsp;(3) 积分可在指定店铺查询或通过指定网站或adiCLUB客服中心查询。</p>\n        <p>&nbsp;&nbsp;(4) 以下情况不积分：- 非在指定网站或指定店铺进行购买 -明示不参与积分的特定商品 - 促销活动礼品或赠品 - 通过阿迪达斯团购渠道购买的商品 - 通过员工折扣卡购买的商品 - 会员将所购商品在淘宝等第三方网站、销售渠道进行商业性转售，所购金额不积分，已产生积分的阿迪达斯有权扣除或调整</p>\n        <p>&nbsp;&nbsp;(5) 会员有不诚实交易行为的，阿迪达斯有权取消交易记录、扣除或调整积分、或限制会员积分的累计和使用。</p>\n        <p>&nbsp;&nbsp;(6) 在上述第(5)项情形下，如果会员对是否发生“不诚实交易行为”有疑义的，会员应在14日内向阿迪达斯提出并提交阿迪达斯所需的材料，阿迪达斯将在10个工作日内告知会员处理结果。</p>\n        <p>&nbsp;&nbsp;(7) 在上述第(6)项情形下，会员于阿迪达斯发出通知之日起30日内没有异议的，视作会员接受处理结果。</p>\n        <p>&nbsp;&nbsp;(8) 任何积分不能转移、转让或赠送给第三人。</p>\n        <p>&nbsp;&nbsp;(9) 积分不能折现、找零或偿还。</p>\n        <p>&nbsp;&nbsp;(10)阿迪达斯可能视情况对积分规则进行不时变更。阿迪达斯将通过指定店铺和指定网站不断更新信息告知会员如何使用积分和如何累计积分。如果阿迪达斯合理认为变更事项会对会员产生重大不利影响的，阿迪达斯应通过指定店铺和指定网站或其他途径提前30天通知会员。</p>\n        <p>7-2. 优惠券的定义和使用</p>\n        <p> &nbsp;&nbsp;(1)铜牌及以上等级会员可享用普通优惠券，该优惠券为购物所产生积分由系统自动兑换产生。在指定网站购物的，在下单（并无退货情况）后的第21天，购物所产生的积分将进入待兑换状态；在指定店铺购物的，在购物（并无退货情况）后的第8天，购物所产生的积分将进入待兑换状态。铜牌及以上等级会员每累计满500待兑换积分，系统将自动兑换成50元普通优惠券。</p>\n        <p>&nbsp;&nbsp;(2) 只有铜牌会员/银座会员/金尊会员才可享受积分自动兑换成普通优惠券的会员权益。新标会员只可消费积分，不可积分兑换成普通优惠券。</p>\n        <p>&nbsp;&nbsp;(3) 普通优惠券以现金折扣方式使用，可用于除下文第(9)项列明的商品外的其他商品。</p>\n        <p>&nbsp;&nbsp;(4) 系统兑换生成普通优惠券时，与经核准的优惠券金额相当的积分将被扣除。普通优惠券可于生成之日起90天内使用。有效期过后，普通优惠券不得再使用。在指定店铺使用普通优惠券时应出示正确的手机号码及会员姓名；在指定网站使用时，需登录个人账号。</p>\n        <p>&nbsp;&nbsp;(5) 普通优惠券生成发放信息通过手机短信或者微信送达。会员也可通过指定网站、指定店铺及adiCLUB客服中心查询该信息。</p>\n        <p>&nbsp;&nbsp;(6) 除普通优惠券外，阿迪达斯还将不定期向所有或特定会员发放促销优惠券和其他优惠券。优惠券使用条件及有效期在每次发券时通过指定网站、指定店铺、短信、电邮等途径向会员公示。</p>\n        <p>&nbsp;&nbsp;(7) 使用优惠券时，如果商品的价格低于优惠券的金额，差额部分不退还。</p>\n        <p>&nbsp;&nbsp;(8) 仅会员可凭其会员凭证使用所生成和发放的优惠券。</p>\n        <p>&nbsp;&nbsp;(9) 以下情形不得使用优惠券：\n          <br>- 打折商品\n          <br>- 阿迪达斯指定限量版商品\n          <br>- 在指定网站和指定店铺之外的渠道购买的商品\n          <br>- 明示不得使用优惠券的商品\n          <br>- 促销后动礼品或赠品\n          <br>- 通过阿迪达斯团购渠道购买的商品\n          <br>- 优惠券规定使用条件外的购买\n          <br>- 阿迪达斯已事先向会员公示的其他情况\n        </p>\n        <p>&nbsp;&nbsp;(10) 商品购买后，会员可根据阿迪达斯公示的退换货政策、凭经认可的正式收据退还商品。商品退还的，购买该商品产生的积分将取消；此外，若在购买该商品时使用了优惠券的，已使用的优惠券将返还阿迪达斯，不退还到会员账户。若购买时使用的是积分兑换的普通优惠券，退货后优惠券将以积分的形式返还会员账户。若会员使用普通优惠券购买多个商品时，优惠券项下的折扣金额将按购买商品时的售价比例分摊到每个商品上。若发生部分商品退货的，退货部分商品购买时的售价扣除分摊到该等商品的优惠券折扣金额后的余额将退还给会员，退货部分商品所对应的优惠券分摊折扣金额将以积分形式返还会员账户。优惠券金额或优惠券分摊折扣金额每1元转换为10积分（未满1元的部分不转换为积分也不以其他形式退回）。若使用的是其他优惠券的，优惠券将不以任何形式予以退回。</p>\n        <p>&nbsp;&nbsp;(11) 即使优惠券未经使用而失效，因兑换生成优惠券而被扣除的积分不予恢复。</p>\n        <p>7-3. 积分更正 </p>\n        <p>(1) 任何积分累计错误都可以在30日内被更正。如果会员30日后发现积分累计错误且错误是由阿迪达斯原因导致的，会员可以在30日内提交相关正式材料要求阿迪达斯更正积分错误。会员出示正式收据或其他阿迪达斯认可的文件，阿迪达斯将于60日内更正。(2) 阿迪达斯负责积分的操作和管理。经阿迪达斯最终认可的积分都被正式接受。在特定情况下，阿迪达斯有权扣除或调整积分，会员可以在30日内对扣除或调整积分的决定提出异议。</p>\n        <p>7-4. 积分期限</p>\n        <p>积分自生成之日起12个月有效。12个月以后，如果没有在该期间使用的，过期积分自动作废。</p>\n        <p>如任何积分根据本规则被取消、扣除或作废的，则剔除该等积分后的剩余积分自动成为最后积分。</p>\n        <h6>8. 会员资格终止 </h6>\n        <p>8-1. 以下情形出现时，阿迪达斯有权通知会员终止其会员资格， 但以下第(3)项情形发生时，阿迪达斯无须通知即可终止会员资格。(1) 会员申请信息被发现不真实。(2) 错误地积累和使用积分，或会员为除本规则外的其他目的使用会员服务。(3) 会员死亡。(4) 会员扰乱其他会员的活动，或利用其他会员个人信息对其他会员造成损害，或有其他侵犯他人合法权益的行为。(5) 会员违反本规则的条款和条件或损害公共秩序、公序良俗。(6) 会员将所购商品在淘宝等第三方网站，销售渠道进行商业性转售的，阿迪达斯保留取消会员资格的权利。 </p>\n        <p>8-2. 在任何时候，任何会员都可于确认身份后，通过指定网站或adiCLUB客服中心申请终止其会员资格，阿迪达斯将在24小时内启动终止程序。</p>\n        <p>8-3.一旦会员资格终止，所有的积分、优惠券和其他会员权益将立即到期失效，重新申请入会，上述权益也将不予恢复。</p>\n        <h6>9. 隐私条款 </h6>\n        <p>9-1. 阿迪达斯使用您分享的信息，期以提升我们的服务和您的体验。阿迪达斯尊重会员的隐私，有关阿迪达斯自营的指定网站或指定店铺对您个人信息的收集、使用和保护请见附件一《隐私声明》。《隐私声明》构成本规则不可分割的一部分。在您成为会员、使用会员服务前，请务必认真阅读《隐私声明》。若您使用指定网站或会员服务，即视为您同意阿迪达斯根据《隐私声明》使用和保护您的个人信息。</p>\n        <p>9-2. 经销商或其他授权第三方运营的指定店铺或指定网站对您个人信息的收集、使用和保护请参见其各自公示的相关隐私政策， 在您成为会员、使用会员服务前，请务必索要并阅读。无论该等隐私政策有何相反规定，如果您通过经销商或其他授权第三方运营的指定店铺或指定网站申请注册成为会员或享受会员服务的，则视为您同意该等经销商和授权第三方与阿迪达斯分享其收集的与您相关的所有个人信息和其他信息。阿迪达斯将会参照《隐私声明》使用和保护经销商和授权第三方与我们分享的您的相关信息。</p>\n        <p>9-3. 若您不同意本第9条或第9条引述的任何条款、条件和规则（包括但不限于附件一《隐私声明》）或其任何一部分，请立即停止使用会员服务。</p>\n        <h6>10. 损害赔偿；责任限制 </h6>\n        <p>10-1. 您同意赔偿阿迪达斯及其集团公司成员、管理人员、董事、雇员、代理人、许可人以及供应商由于您的行为、您对本规则的违反、您的违法行为或您侵犯第三方权利所引起的或与之相关的任何指控、损失、责任、费用、损害赔偿，为其辩护并使其免受损害。</p>\n        <p>10-2. 除非法律另有明确规定，阿迪达斯不对任何类型的任何间接、附带、特别、惩戒、罚款或结果性损害承担任何责任，无论是如何发生的，亦无论是因侵权、违反合同或其他原因造成的。在中国法律允许的最大范围内，阿迪达斯声明未作出其他任何保证，无论是何种类的，但不排除适用针对消费者可能无法合法排除的任何保证。除非法律另有明确规定，没有明确证据证明阿迪达斯具有故意或重大过失的，阿迪达斯对会员的损害或损失不负赔偿责任。11. adiCLUB客户服务中心 </p>\n        <p>adiCLUB客服中心电话：4008801515</p>\n        <p>adiCLUB客服中心工作时间为上午9点至下午6点（双休日及节假日不营业）</p>\n        <h6>12. 适用法律；管辖</h6>\n        <p>12-1. 任何因本规则引起的争议，对本规则的解释或其他本规则未明确事项将适用中国相关法律；如法律无明确规定的，参照商业或行业惯例解决。</p>\n        <p>12-2. 因本规则引起的或与本规则有关的任何争议或纠纷，应在可能的范围内，由您和阿迪达斯通过诚信友好协商加以解决。若协商不成的，该等争议或纠纷应提交至阿迪达斯注册所在地地有管辖权的中国法院的司法管辖。 </p>\n        <p>12-3.如果本规则中的某一条款无效，不影响其他条款继续有效。如果本规则中的某一条款被认定是违法、无效或不可执行，则该部份将被视为与本规则相分割，本规则的其余所有条款之有效性及可执行性均不受其影响。</p>\n        <h3>隐私声明</h3>\n        <p>我们，阿迪达斯体育(中国)有限公司(阿迪达斯)，力求给您最佳的阿迪达斯体验。我们使用您与我们分享的信息，期以提升我们的服务和您的体验。本隐私声明旨在让您清楚地了解，我们会如何使用您的信息，我们保护您的信息的决心，以及您拥有的管理自身信息和隐私的各种选择。您使用我们的网站、应用程序或服务，即视为您同意阿迪达斯根据本隐私声明使用和保护您的个人信息。若您不同意本隐私声明或其任何一部分，请立即停止使用我们的网站、应用程序和服务。</p>\n        <p>阿迪达斯(中国)有限公司隶属阿迪达斯集团，阿迪达斯集团系由adidas AG (Adi-Dassler-Straße 1, 91074 Herzogenaurach, Germany)组建。</p>\n        <p>我们从您处收集的信息</p>\n        <p>我们将信息用于多种用途，例如：处理您的订单、邀请您参加我们的活动、或向您发送相关营销信息。下文将概述我们从您处收集何种信息、以及如何取得信息。</p>\n        <h6>您提供给我们的信息</h6>\n        <p>若您注册阿迪达斯账号或申请注册成为adiCLUB会员，我们会要求提供个人信息，诸如：您的姓名、电邮地址、电话号码、性别、个人偏好和生日等信息。</p>\n        <p>当您使用我们的服务，您可能需要向我们提供个人信息，比如：当您在我们的网店下达订单时您需要提供您的邮寄地址和付款详情，当您报名参加我们的比赛或活动时你需要提供您的电邮地址。若您联系我们的客服，同样会记录在案。</p>\n        <p>当您订阅我们的简讯，我们会保存您的电邮地址，以向您提供关于阿迪达斯的服务和产品的定期电邮更新。 </p>\n        <p>一旦您对我们的简讯有兴趣，您可首先提交简讯请求。此后，您将收到一份电邮，内含一个需点击以完成注册的链接，以进行确认。我们使用这种双重选择确认程序，以确保电邮账号持有人希望收到我们的简讯。您可随时退订我们的简讯，只要使用我们的每份简讯电邮内含的“退订”链接，或向我们发送一份电邮或函件。</p>\n        <p>最后，我们提供各种应用程序，让您上传和/或存储相关信息。取决于不同的应用程序，此类信息可能包括运动数据和身体尺寸，例如：体重、身高和心律。此类敏感信息仅会用于发挥应用程序的功能之用。若我们有意将此类信息用于其他用途，我们将告知您并取得您的明示同意。</p>\n        <h6>通过您与我们的互动取得的信息</h6>\n        <p>当您与我们的品牌、网站和应用程序互动，我们也可能收集相关信息，以及您是如何使用该等品牌、网站和应用程序的。此类信息包括：</p>\n        <p>网站：我们可能收集您浏览的各网站的相关信息，以及您是如何使用各网站的。每次您浏览我们的网站，数据会从您的浏览器发送到我们的服务器。此类信息有助优化我们的服务，提升您在我们的网站和应用程序的个性化体验。此类信息包括：</p>\n        <p>您的IP地址</p>\n        <p>浏览日期和时间</p>\n        <p>转引URL(即访客是从哪个网址转至我们网站的)</p>\n        <p>在我们的网站浏览的网页</p>\n        <p>设备和浏览器相关信息(浏览器类型和版本、操作系统等)。</p>\n        <p>位置信息：当您使用定位服务(例如：跑步应用程序)，我们会收集并处理与您的实际位置相关的信息，如移动设备发送的GPS信号。我们也会使用各类技术来进行定位，例如您的设备发散的感应数据可提供比如您附近Wi-Fi接入点、近场通信(NFC)和蜂窝塔等相关信息。请注意，一般而言，您可通过变更设备或浏览器的设置而禁用地址发送功能，此外，当我们利用地址信息时，我们将告知您。</p>\n        <p>Cookies和其他识别符：当您浏览我们的网站或使用我们的应用程序，我们和我们的业务伙伴会使用各类技术收集和存储相关信息，其中可能包括发送一个或多个cookies或其他识别码到您的设备。欲知我们对cookies和识别码的使用、以及如何禁用它们，请查阅我们网站和应用程序的cookies相关政策。</p>\n        <p>匿名使用我们的网站：您可匿名浏览我们的网站，并不透露个人数据。此时，我们收集的信息是匿名的，不会与您个人直接关联。匿名信息包括(例如)我们的网站的访客数量或浏览习惯。我们收集和分析此类信息，旨在增进对消费者兴趣和需求的理解，以便我们持续提升服务水平。为保持匿名状态，您可禁用上文所述的cookies和识别码。这样，您的个人信息就不会被收集，除非您选择向我们提供此类信息，例如，通过使用我们的网店。</p>\n        <h6>第三方分享给我们的信息</h6>\n        <p>您可能会在阿迪达斯授权经销商运营的阿迪达斯店铺购物，也可能会使用阿迪达斯授权经销商或其他第三方运营的经授权的阿迪达斯网站、应用程序和服务，您使用该等经销商或第三方的网站、应用程序或服务须受该等授权经销商和第三方的服务条款及隐私政策约束，您需要索要并仔细阅读其条款。在特定情况下（如您通过授权经销商或其他第三方运营的店铺或网站申请注册成为adiCLUB会员或享受会员服务的），阿迪达斯授权经销商或其他第三方将会与我们分享其收集的与您相关的所有个人信息和其他信息。</p>\n        <h6>未成年人保护</h6>\n        <p>阿迪达斯致力于保护未成年人的隐私，且无意收集未成年人的个人资料。也不建议未成年人使用我们的网站或服务，除非所在地法律允许并且监护人同意，未成年人请不要注册账户或发送自己的姓名、住址、电话、邮件地址等个人信息给我们。如果我们不小心收集到未成年人的信息，我们在知情后会尽快删除。我们鼓励未成年人的家长和监护人定期检查和监控他们使用电子邮件及参加其它在线活动的情况。</p>\n        <h6>我们如何使用您的信息</h6>\n        <p>在您与我们的互动过程中，我们使用和分析您的信息，以提供并改善我们的服务并用于其他各种目的，详列如下：</p>\n        <p>处理您的订单：我们使用诸如您的姓名、地址和付款详情等信息，以处理和履行您的订单，以及告知您订单的状态。我们也可能使用您的姓名、地址和付款记录，以评估您的信用度。为提供您订购的产品和服务，阿迪达斯将向负责配送您订单的快递公司提供配送所必要的您的个人信息。此外，为付款操作所需，阿迪达斯可能向信用机构或负责处理您付款的付款服务供应商提供您的付款详情。您的信用卡数据将由付款服务供应商直接收集和处理，阿迪达斯不会存储任何信用卡数据。</p>\n        <p>客服：若您联系我们的客服(反之亦然)，我们将使用诸如您的订单信息和联系历史等信息，以处理您的请求，并力求提供最佳服务。</p>\n        <p>其他阿迪达斯服务：我们使用信息以提供诸如adiCLUB会员服务以及促销、活动和应用程序等您请求的其他服务。这可能包括为您累计会员积分和提供其他会员福利，处理比赛和促销申请，使用您的联系详情用于活动，以及使用诸如您的位置等信息用于我们的移动应用程序(例如跑步应用程序)。</p>\n        <p>营销：无论创建阿迪达斯账号并同意我们使用您的信息，或者在线订购我们的产品或服务，我们均可能使用您的信息，向您发送个性化的营销信息，以及用于调研目的。下文详述了我们使用的信息以及如何使用该等信息：</p>\n        <p>信息种类：您与我们品牌的互动方式，向我们提供了关于您的兴趣和偏好的宝贵信息。这使我们得以有机会向您尽力提供最佳阿迪达斯体验。我们使用各种信息（例如您的年龄、位置、您的阿迪达斯采购订单、您的产品评价、您的社交媒体账号、您使用的应用程序和网站以及您是如何使用应用程序和网站的）分析您与我们的品牌的整体互动情况，以了解您和您的兴趣。若获得您的同意，我们会使用此类信息向您发送关于阿迪达斯产品、活动和促销的个性化商业信息。我们也将使用您的经整合的信息，用以整合和创建关乎消费者如何使用我们的产品和体验我们的品牌的报告。</p>\n        <p>渠道种类：当您向我们提供联系信息(例如：您的电邮、电话号码或社交媒体账号)，我们会寻求您的同意，以使用此类信息向您发送我们个性化的营销资讯。若您无意接受特定渠道的资讯(例如短消息)，在我们的资讯内会向您提供退订此类资讯的简单方法。您也可联系我们的客服，要求退订。请注意，我们的部分(移动)应用程序可能也会向您发送资讯，包括(若您已同意)推送信息(比如当您在我们的商店附近时，向您推送新产品资讯)。您可通过变更您的手机或应用程序设置而禁用此类资讯，也可删除应用程序以停止接收资讯。</p>\n        <p>资讯种类：我们发送给您的资讯是个性化定制的，贴合您的个人偏好和兴趣(如上文所述)。直接营销资讯可能包含与我们的产品和服务、活动或促销相关的广告资讯以及阿迪达斯新闻。我们也可能使用各种渠道进行调研，以了解您在阿迪达斯的体验。</p>\n        <p>其他：若我们意欲将您的信息用于本隐私声明列明以外的目的，如果法律要求，我们会征求您的同意。</p>\n        <h6>由您掌控</h6>\n        <p>对我们而言，公平竞争和透明度至关重要。我们希望以透明的方式收集信息，并力求向您提供简便的选择，以访问、编辑或删除您的信息，或行使任何其他您可能享有的关乎您的信息的权利。</p>\n        <h6>信息访问和纠正</h6>\n        <p>只要您订购了我们的产品或服务、或者注册了我们的账号，您便可通过我们的网站访问您的诸多信息。我们的网站通常向您提供选择，以添加、更新或移除我们拥有的关于您的信息。</p>\n        <p>若您无法通过我们的网站访问我们拥有的关于您的任何信息，您可通过以下方式联系我们的客服并提出访问该等信息的请求，在这过程中不会产生任何费用：</p>\n        <p>service@adidas.com</p>\n        <p>400-880-1515转9</p>\n        <p>收到您的请求后，我们将验证您的身份，并向您提供我们拥有的关于您的信息的概览。此概览将包括信息使用目的、信息接收人和信息来源。</p>\n        <p>在您收到请求的信息后，您可选择行使您的权利，例如：请求修正有误信息、或者屏蔽或移除信息。</p>\n        <h6>选择退出或退订</h6>\n        <p>我们的所有营销资讯均内含供您选择日后不再接收资讯的简便方法，例如您可退订的链接。您也可选择退订特定渠道(例如电邮或短消息)的资讯，退订方法列于您在该等渠道收到的资讯之内。我们的部分(移动)应用程序可能也会向您发送资讯，包括推送信息。您可通过变更您的手机或应用程序设置而禁用此类信息，也可选择删除应用程序以停止接收信息</p>\n        <p>若您不再愿意接收我们的所有资讯、也不希望我们将您的信息用于营销目的，您可使用您收到的资讯内含的退订链接发送请求，您也可联系我们的客服service@adidas.com，或者致电400-880-1515转9。</p>\n        <h6>分享信息</h6>\n        <p>我们以谨慎、保密的方式对待您的信息。除本隐私声明另有约定或您另行明确同意之外，我们不会与第三方分享您的信息。 </p>\n        <h6>与阿迪达斯集团其他实体或业务伙伴</h6>\n        <p>对于关乎我们的消费者的匿名的、经整合的信息，我们可能与阿迪达斯集团其他成员或我们的业务伙伴分享，例如用于趋势分析。此类信息是匿名的，无法再行追溯关联至个别消费者。</p>\n        <h6>与服务供应商</h6>\n        <p>我们聘用各类公司(例如服务器托管公司、快递公司、付款服务供应商和信用评级公司)代为处理数据。该等公司代表我们使用您的信息，并受到数据处理所需遵守的严格规则的约束。该等公司仅可根据阿迪达斯的指示使用信息，除此之外的任何行为，均属严格禁止之列。</p>\n        <h6>守法与执法</h6>\n        <p>阿迪达斯不会应第三方的请求而主动披露个人信息，且仅在法律法规、行政机关或司法机关要求时，方会披露信息。</p>\n        <h6>经您同意</h6>\n        <p>我们在事先取得您的有效同意后，才会进一步与其他公司或个人分享您的信息。例如，在您同意的情况下，我们可能与健身中心等公司分享信息。</p>\n        <h6>重新定向</h6>\n        <p>我们的网站和应用程序使用重新定向技术。这使我们得以在业务伙伴的网站上向对我们的商店和产品已表示兴趣的访客显示广告。我们相信，与缺乏个人关联的广告相比，这种个性化的、基于兴趣的广告更易激发我们的消费者的兴趣。</p>\n        <p>我们也与使用追踪技术的公司合作，以代表我们在互联网发布广告。此类公司可能收集您对我们的网站或应用程序的浏览、以及与我们资讯(包括广告)的互动。</p>\n        <p>基于您的过往上网行为，重新定向技术将分析您的cookies，并展示广告。想更多了解cookies，获悉如何禁用重新定向，请查阅我们网站和应用程序的cookies相关政策。</p>\n        <h6>安全</h6>\n        <p>我们承诺保护您的信息，并已采取适当的、系统化的技术措施以保护您的信息，防止信息灭失、篡改、未经授权的访问或泄露、或误用。我们通常对您的信息保留两年(自您与我们的最后一次互动起算)，除非法律或法律程序要求更长的保留期。</p>\n        <h6>联系信息</h6>\n        <p>对于我们使用您的信息、如何行使您的权利、或我们的隐私声明，若有如何疑问，欢迎联系我们：</p>\n        <h6>客户服务</h6>\n        <p>service@adidas.com</p>\n        <p>400-880-1515转9</p><p>若您倾向使用传统邮件，请送达请求至：上海市淮海中路999号上海环贸广场办公楼一期大楼31层，邮编200031。</p>\n        <h6>本政策的变更</h6>\n        <p>阿迪达斯承诺遵循隐私和信息保护的基本原则。因此，我们会定期评估我们的隐私声明，以确保隐私声明正确无误、清晰可辨，其中包含必备内容并在实际操作中得以彻底贯彻，且符合信息保护的原则。本隐私声明可能不时变更，以适应业务的最新进展和机遇、遵循法律规定。本声明的重大变更将在阿迪达斯官方网站adidas.com予以公布，并在公布之日起生效。请您定期查阅本隐私政策内容，及时了解有关变更。如您在变更生效后继续使用我们的网站、应用程序或服务即表示您完全接受这些变更。</p>\n      </div>\n    </div>\n  </div>\n</div>\n\n    ";

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(11);
if(typeof content === 'string') content = [[module.i, content, '']];
// add the styles to the DOM
var update = __webpack_require__(1)(content, {});
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../node_modules/css-loader/index.js!../../../node_modules/postcss-loader/index.js!./normalize-5.0.0.min.css", function() {
			var newContent = require("!!../../../node_modules/css-loader/index.js!../../../node_modules/postcss-loader/index.js!./normalize-5.0.0.min.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),
/* 7 */,
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(13);
if(typeof content === 'string') content = [[module.i, content, '']];
// add the styles to the DOM
var update = __webpack_require__(1)(content, {});
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../node_modules/css-loader/index.js!../../../node_modules/postcss-loader/index.js!../../../node_modules/sass-loader/lib/loader.js!./index.scss", function() {
			var newContent = require("!!../../../node_modules/css-loader/index.js!../../../node_modules/postcss-loader/index.js!../../../node_modules/sass-loader/lib/loader.js!./index.scss");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function ajaxSend(handle) {
    handle();
}
exports.ajaxSend = ajaxSend;


/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var DomAPI = (function () {
    function DomAPI(elemSelector, elemParents) {
        this.elemSelector = elemSelector;
        this.elemParents = elemParents || [];
    }
    /**
     * 设置类的可操作的Dom元素列表
     *
     * @param {Array<Element>} elemList
     * @memberof DomAPI
     */
    DomAPI.prototype.setElemList = function (elemList) {
        this.elemList = elemList;
    };
    /**
     * 返回可以操作的Dom元素个数
     *
     * @returns {number}
     * @memberof DomAPI
     */
    DomAPI.prototype.size = function () {
        return this.getElemList().length;
    };
    /**
     * 获取Dom元素列表
     * 仅只能这样获取
     *
     * @param {number} [index]
     * @returns {Array<Element>}
     * @memberof DomAPI
     */
    DomAPI.prototype.getElemList = function (index) {
        var _this = this;
        if (this.elemList == null) {
            this.elemParents = [].slice.call(this.elemParents);
            if (this.elemParents.length === 0) {
                this.elemList = _$s(this.elemSelector);
            }
            else {
                this.elemList = [];
                this.elemParents.forEach(function (elemParent) {
                    _this.elemList = ([].slice.call(_$s(_this.elemSelector, elemParent))).concat(_this.elemList);
                });
            }
        }
        return this.elemList;
    };
    /**
     * 返回指定下标的Dom元素
     * 同比eq方法
     *
     * @param {number} index
     * @returns
     * @memberof DomAPI
     */
    DomAPI.prototype.getEl = function (index) {
        var list = this.getElemList();
        return list[index];
    };
    /**
     * 返回指定下标的DomAPI类型Dom元素
     * 同比getEl方法
     *
     * @param {number} index
     * @returns {DomAPI}
     * @memberof DomAPI
     */
    DomAPI.prototype.eq = function (index) {
        return DomAPI.CreateByElem(this.getElemList()[index]);
    };
    /**
     * 遍历当前控制元素
     *
     * @param {(elem: Element, index: number) => void} handle
     * @memberof DomAPI
     */
    DomAPI.prototype.each = function (handle) {
        this.getElemList().forEach(function (thisElem, thisIndex) { return handle(thisElem, thisIndex); });
    };
    /**
     * 获取元素数组中的一部分，参数详情参考Array.slice
     *
     * @param {number} [start]
     * @param {number} [end]
     * @returns
     * @memberof DomAPI
     */
    DomAPI.prototype.slice = function (start, end) {
        return DomAPI.CreateByElemList(this.getElemList().slice(start, end));
    };
    /**
     * 在当前Dom元素下的查找选择器的元素
     *
     * @param {string} selector
     * @returns {DomAPI}
     * @memberof DomAPI
     */
    DomAPI.prototype.find = function (selector) {
        return new DomAPI(selector, this.getElemList());
    };
    /**
     * 把元素添加当前可操作元素的最后一个子元素的后面
     *
     * @param {Array<Element>} insertElemList
     * @memberof DomAPI
     */
    DomAPI.prototype.append = function (insertElemList) {
        this.getElemList().forEach(function (elem) {
            insertElemList.forEach(function (insertElem) {
                elem.appendChild(insertElem);
            });
        });
    };
    /**
     * 把元素添加当前可操作元素的第一个子元素的前面
     * 按数组顺序添加
     *
     * @param {Array<Element>} insertElemList
     * @memberof DomAPI
     */
    DomAPI.prototype.appendBefore = function (insertElemList) {
        this.getElemList().forEach(function (elem) {
            for (var i = insertElemList.length - 1; i >= 0; i--) {
                elem.insertBefore(insertElemList[i], elem.children[0]);
            }
        });
    };
    /**
     * 把元素插入到当前元素的前面
     *
     * @param {Array<Element>} elemList
     * @memberof DomAPI
     */
    DomAPI.prototype.insertFront = function (elemList) {
        var _this = this;
        elemList.forEach(function (newElem) {
            _this.getElemList().forEach(function (meElem) { return meElem.parentElement.insertBefore(newElem, meElem); });
        });
    };
    /**
     * 把当前元素从渲染树中删除
     *
     * @memberof DomAPI
     */
    DomAPI.prototype.remove = function () {
        this.getElemList().forEach(function (elem) {
            if (elem.parentNode) {
                elem.parentNode.removeChild(elem);
            }
        });
    };
    /**
     * 用新元素替换当前元素
     *
     * @param {Element} newElem
     * @memberof DomAPI
     */
    DomAPI.prototype.replace = function (newElem) {
        this.getElemList().forEach(function (oldElem) { return oldElem.parentElement.replaceChild(newElem, oldElem); });
    };
    /**
     * 获取元素的父元素
     *
     * @returns {DomAPI}
     * @memberof DomAPI
     */
    DomAPI.prototype.parent = function () {
        var parentList = [];
        this.getElemList().forEach(function (elem) {
            parentList.push(elem.parentElement);
        });
        return DomAPI.CreateByElemList(parentList);
    };
    /**
     * 获取所有满足条件的父元素
     *
     * @param {string} parentElementSelector
     * @returns {DomAPI}
     * @memberof DomAPI
     */
    DomAPI.prototype.parents = function (parentElementSelector) {
        var parentList = [];
        if (parentElementSelector) {
            var parentCandidate = new DomAPI(parentElementSelector).getElemList();
            var pElem_1 = this.getEl(0).parentElement;
            while (pElem_1.tagName.toUpperCase() == 'body'.toUpperCase()) {
                parentCandidate.forEach(function (parentElementElem) {
                    if (pElem_1 == parentElementElem) {
                        parentList.push(parentElementElem);
                    }
                });
                pElem_1 = pElem_1.parentElement;
            }
        }
        return DomAPI.CreateByElemList(parentList);
    };
    /**
     * 给当前元素添加处理事件
     * 事件名可以以空格分割添加多个事件，如："click change input", "click"
     *
     * @param {string} eventType
     * @param {(ev) => void} handle
     * @memberof DomAPI
     */
    DomAPI.prototype.on = function (eventType, handle) {
        EventCustomize.On(this.getElemList(), eventType, handle);
    };
    /**
     * 从当前元素删除处理事件
     * 事件名可以以空格分割添加多个事件，如："click change input", "click"
     *
     * @param {string} eventType
     * @param {(ev) => void} handle
     * @memberof DomAPI
     */
    DomAPI.prototype.off = function (eventType, handle) {
        EventCustomize.Off(this.getElemList(), eventType, handle);
    };
    /**
     * 给当前元素设置css样式
     * 如{display: 'none', "font-size": "28px", fontSize: "28px"}
     *
     * @param {Object} cssStyle
     * @memberof DomAPI
     */
    DomAPI.prototype.css = function (cssStyle) {
        this.getElemList().forEach(function (elem) {
            try {
                for (var cssName in cssStyle) {
                    if (cssStyle.hasOwnProperty(cssName)) {
                        var anyElem = elem;
                        anyElem.style[cssName] = cssStyle[cssName];
                    }
                }
            }
            catch (e) {
                console.error('DomAPI.css error');
            }
        });
    };
    /**
     * 设置元素的高度
     *
     * @param {number} h
     * @memberof DomAPI
     */
    DomAPI.prototype.height = function (h) {
        this.css({ height: h + 'px' });
    };
    /**
     * 设置元素的宽度
     *
     * @param {number} w
     * @memberof DomAPI
     */
    DomAPI.prototype.width = function (w) {
        this.css({ width: w + 'px' });
    };
    /**
     * 获取元素的属性值
     * 仅获取第一个元素的属性值
     *
     * @param {any} name
     * @returns {string}
     * @memberof DomAPI
     */
    DomAPI.prototype.getAttr = function (name) {
        if (this.getElemList()[0]) {
            return CommonAttr.get(this.getElemList()[0], name);
        }
        else {
            return '';
        }
    };
    /**
     * 设置元素的属性值
     * 全部元素设置
     *
     * @param {string} name
     * @param {string} value
     * @memberof DomAPI
     */
    DomAPI.prototype.setAttr = function (name, value) {
        this.getElemList().forEach(function (elem) { return CommonAttr.set(elem, name, value); });
    };
    /**
     * 删除元素的属性值
     * 所有元素
     *
     * @param {any} name
     * @memberof DomAPI
     */
    DomAPI.prototype.removeAttr = function (name) {
        this.getElemList().forEach(function (elem) { return CommonAttr.remove(elem, name); });
    };
    /**
     * 清除元素所有子元素
     *
     * @memberof DomAPI
     */
    DomAPI.prototype.empty = function () {
        this.getElemList().forEach(function (elem) { return elem.innerHTML = ''; });
    };
    /**
     * 设置元素显示文本
     * 会先清除元素内的所有内容，后再设置文本
     *
     * @param {string} text
     * @memberof DomAPI
     */
    DomAPI.prototype.text = function (text) {
        var textElem = document.createTextNode(text);
        this.empty();
        this.getElemList().forEach(function (elem) {
            elem.appendChild(textElem.cloneNode());
        });
    };
    /**
     * 对元素内部html进行赋值
     *
     * @param {string} html
     * @memberof DomAPI
     */
    DomAPI.prototype.html = function (html) {
        this.getElemList().forEach(function (elem) {
            elem.innerHTML = html;
        });
    };
    /**
     * dom节点添加className
     *
     * @param {string} className
     * @memberof DomAPI
     */
    DomAPI.prototype.addClass = function (className) {
        this.getElemList().forEach(function (elem) { return ClassCustomize.addClass(elem, className); });
    };
    /**
     * dom节点删除className
     *
     * @param {string} className
     * @memberof DomAPI
     */
    DomAPI.prototype.removeClass = function (className) {
        this.getElemList().forEach(function (elem) { return ClassCustomize.removeClass(elem, className); });
    };
    /**
     * 判断元素是否包含className
     * 所有元素包含className，返回true；否则返回false
     *
     * @param {string} className
     * @returns {boolean}
     * @memberof DomAPI
     */
    DomAPI.prototype.containClass = function (className) {
        var elemList = this.getElemList();
        for (var i = 0, len = elemList.length; i < len; i++) {
            if (ClassCustomize.containsClass(elemList[i], className) == false) {
                return false;
            }
        }
        return true;
    };
    /**
     * 包含className的元素过滤器
     * 包含className的执行yesHandle函数
     * 不包含className的执行noHandle函数
     *
     * @param {string} className
     * @param {(elem) => void} yesHandle
     * @param {(elem) => void} noHandle
     * @memberof DomAPI
     */
    DomAPI.prototype.containClassFilter = function (className, yesHandle, noHandle) {
        this.getElemList().forEach(function (elem) {
            if (ClassCustomize.containsClass(elem, className)) {
                yesHandle(elem);
            }
            else {
                noHandle(elem);
            }
        });
    };
    /**
     * addClass与removeClass切换
     * className存在就remove，不存在就add
     *
     * @param {string} className
     * @memberof DomAPI
     */
    DomAPI.prototype.toggleClass = function (className) {
        this.getElemList().forEach(function (elem) {
            if (ClassCustomize.containsClass(elem, className)) {
                ClassCustomize.removeClass(elem, className);
            }
            else {
                ClassCustomize.addClass(elem, className);
            }
        });
    };
    /**
     * 显示元素
     *
     * @memberof DomAPI
     */
    DomAPI.prototype.show = function () {
        this.css({ display: 'block' });
    };
    /**
     * 隐藏元素
     *
     * @memberof DomAPI
     */
    DomAPI.prototype.hide = function () {
        this.css({ display: 'none' });
    };
    /**
     * 获取第一个元素距离顶部有多高
     * default 0
     *
     * @returns {number}
     * @memberof DomAPI
     */
    DomAPI.prototype.positionTop = function () {
        var thiselem = this.getElemList()[0];
        var top = 0;
        if (thiselem) {
            try {
                var a = thiselem;
                var elem = a;
                while (elem.tagName != 'BODY' && elem.tagName != 'HTML') {
                    top += elem.offsetTop;
                    elem = elem.parentElement;
                }
            }
            catch (e) {
                console.error('DomAPI positionTop error');
            }
        }
        return top;
    };
    /**
     * 通过字符串创建DomAPI类
     *
     * @static
     * @param {string} htmlStr
     * @returns {DomAPI}
     * @memberof DomAPI
     */
    DomAPI.CreateByHtmlString = function (htmlStr) {
        var a = new DomAPI();
        a.setElemList(CommonFastRender(htmlStr));
        return a;
    };
    /**
     * 通过dom数组创建DomAPI类
     *
     * @static
     * @param {Array<Element>} elemList
     * @returns {DomAPI}
     * @memberof DomAPI
     */
    DomAPI.CreateByElemList = function (elemList) {
        var a = new DomAPI();
        a.setElemList(elemList);
        return a;
    };
    /**
     * CreateByElemList方法的缩写
     *
     * @static
     * @param {Array<Element>} elemList
     * @returns {DomAPI}
     * @memberof DomAPI
     */
    DomAPI.Create = function (elemList) {
        return DomAPI.CreateByElemList(elemList);
    };
    /**
     * 通过一个元素创建DomAPI类
     *
     * @static
     * @param {Element} elem
     * @returns {DomAPI}
     * @memberof DomAPI
     */
    DomAPI.CreateByElem = function (elem) {
        return DomAPI.CreateByElemList([elem]);
    };
    return DomAPI;
}());
DomAPI.version = '0.0.4';
exports.DomAPI = DomAPI;
var CommonAttr = (function () {
    function CommonAttr() {
    }
    CommonAttr.get = function (elem, name) {
        return elem.getAttribute(name);
    };
    CommonAttr.set = function (elem, name, value) {
        elem.setAttribute(name, value);
    };
    CommonAttr.remove = function (elem, name) {
        elem.removeAttribute(name);
    };
    return CommonAttr;
}());
var EventCustomize = (function () {
    function EventCustomize() {
    }
    EventCustomize.On = function (elemList, eventType, next, useCapture) {
        if (useCapture === void 0) { useCapture = true; }
        elemList.forEach(function (elem) {
            EventCustomize.Bind(elem, eventType, next, useCapture);
        });
    };
    EventCustomize.Bind = function (elem, eventType, next, useCapture) {
        var eventTypes = eventType.split(' ');
        eventTypes.forEach(function (eventType) {
            elem.addEventListener(eventType, next, useCapture);
        });
    };
    EventCustomize.Off = function (elemList, eventType, next, useCapture) {
        if (useCapture === void 0) { useCapture = true; }
        elemList.forEach(function (elem) {
            EventCustomize.UnBind(elem, eventType, next, useCapture);
        });
    };
    EventCustomize.UnBind = function (elem, eventType, next, useCapture) {
        var eventTypes = eventType.split(' ');
        eventTypes.forEach(function (eventType) {
            elem.removeEventListener(eventType, next, useCapture);
        });
    };
    return EventCustomize;
}());
function CommonFastRender(str) {
    var div = document.createElement('div');
    div.innerHTML = str;
    var childElements = [];
    for (var i = 0, len = div.children.length - 1; i <= len; i++) {
        if (div.children[i].nodeType == 1) {
            childElements.push(div.children[i]);
        }
    }
    return childElements;
}
function _$(selector, elem) {
    return elem ? elem.querySelector(selector) : document.querySelector(selector);
}
function _$s(selector, elem) {
    var nodeList = elem ? elem.querySelectorAll(selector) : document.querySelectorAll(selector);
    var elemList = [];
    for (var i = 0, len = nodeList.length; i < len; i++) {
        elemList[i] = nodeList[i];
    }
    return elemList;
}
var ClassCustomize = (function () {
    function ClassCustomize() {
    }
    ClassCustomize.addClass = function (elem, className) {
        if (!elem) {
            return 'there is no elem';
        }
        var classList = ClassCustomize.getClassList(elem);
        if (ClassCustomize.contains(classList, className) < 0) {
            classList.push(className);
        }
        ClassCustomize.setClassList(elem, classList);
        return elem;
    };
    ClassCustomize.removeClass = function (elem, className) {
        var classList = ClassCustomize.getClassList(elem);
        var index = ClassCustomize.contains(classList, className);
        if (index >= 0) {
            classList.splice(index, 1);
            ClassCustomize.setClassList(elem, classList);
        }
    };
    ClassCustomize.containsClass = function (elem, className) {
        var classList = ClassCustomize.getClassList(elem);
        if (ClassCustomize.contains(classList, className) < 0) {
            return false;
        }
        return true;
    };
    ClassCustomize.setClassList = function (elem, classList) {
        elem.className = classList.join(' ');
    };
    ClassCustomize.getClassList = function (elem) {
        var classList = (elem.className || '').split(' ');
        for (var i = classList.length - 1; i >= 0; i--) {
            if (classList[i] === '') {
                classList.splice(i, 1);
            }
        }
        return classList;
    };
    ClassCustomize.contains = function (classList, className) {
        for (var i = 0, len = classList.length; i < len; i++) {
            if (classList[i] == className) {
                return i;
            }
        }
        return -1;
    };
    return ClassCustomize;
}());


/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)(undefined);
// imports


// module
exports.push([module.i, "button, hr, input{overflow:visible}audio, canvas, progress, video{display:inline-block}progress, sub, sup{vertical-align:baseline}html{font-family:sans-serif;line-height:1.15;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}body{margin:0} menu, article, aside, details, footer, header, nav, section{display:block}h1{font-size:2em;margin:.67em 0}figcaption, figure, main{display:block}figure{margin:1em 40px}hr{-moz-box-sizing:content-box;box-sizing:content-box;height:0}code, kbd, pre, samp{font-family:monospace,monospace;font-size:1em}a{background-color:transparent;-webkit-text-decoration-skip:objects}a:active, a:hover{outline-width:0}abbr[title]{border-bottom:none;text-decoration:underline;text-decoration:underline dotted}b, strong{font-weight:bolder}dfn{font-style:italic}mark{background-color:#ff0;color:#000}small{font-size:80%}sub, sup{font-size:75%;line-height:0;position:relative}sub{bottom:-.25em}sup{top:-.5em}audio:not([controls]){display:none;height:0}img{border-style:none}svg:not(:root){overflow:hidden}button, input, optgroup, select, textarea{font-family:sans-serif;font-size:100%;line-height:1.15;margin:0}button, input{}button, select{text-transform:none}[type=submit], [type=reset], button, html [type=button]{-webkit-appearance:button}[type=button]::-moz-focus-inner, [type=reset]::-moz-focus-inner, [type=submit]::-moz-focus-inner, button::-moz-focus-inner{border-style:none;padding:0}[type=button]:-moz-focusring, [type=reset]:-moz-focusring, [type=submit]:-moz-focusring, button:-moz-focusring{outline:ButtonText dotted 1px}fieldset{border:1px solid silver;margin:0 2px;padding:.35em .625em .75em}legend{-moz-box-sizing:border-box;box-sizing:border-box;color:inherit;display:table;max-width:100%;padding:0;white-space:normal}progress{}textarea{overflow:auto}[type=checkbox], [type=radio]{-moz-box-sizing:border-box;box-sizing:border-box;padding:0}[type=number]::-webkit-inner-spin-button, [type=number]::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}[type=search]::-webkit-search-cancel-button, [type=search]::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}[hidden], template{display:none}", ""]);

// exports


/***/ }),
/* 12 */,
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)(undefined);
// imports


// module
exports.push([module.i, ".pc-wrapper {\n  max-width: 1920px;\n  margin: 0 auto;\n  min-width: 1200px; }\n  .pc-wrapper .part-1, .pc-wrapper .part-2, .pc-wrapper .part-3 {\n    width: 100%;\n    position: relative; }\n    .pc-wrapper .part-1 img, .pc-wrapper .part-2 img, .pc-wrapper .part-3 img {\n      width: 100%;\n      display: block; }\n    .pc-wrapper .part-1 .op, .pc-wrapper .part-2 .op, .pc-wrapper .part-3 .op {\n      visibility: hidden; }\n    .pc-wrapper .part-1 video, .pc-wrapper .part-2 video, .pc-wrapper .part-3 video {\n      position: absolute;\n      top: 0;\n      left: 0;\n      width: 100%;\n      height: 100%; }\n  .pc-wrapper .part-3 {\n    position: relative; }\n    .pc-wrapper .part-3 .action-ajax-click {\n      position: absolute;\n      left: 40.83333%;\n      width: 17.76042%;\n      top: 23.33333%;\n      height: 5.8156%;\n      cursor: pointer; }\n    .pc-wrapper .part-3 .action-rule-click {\n      position: absolute;\n      left: 46.82292%;\n      width: 11.61458%;\n      top: 5.1773%;\n      height: 5.03546%;\n      cursor: pointer; }\n\n.rule-float {\n  display: none;\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  background: rgba(0, 0, 0, 0.85); }\n  .rule-float .float-wrapper {\n    position: absolute;\n    height: 80%;\n    top: 10%;\n    left: 50%;\n    width: 1000px;\n    margin-left: -500px;\n    color: #fff;\n    line-height: 1.8; }\n    .rule-float .float-wrapper .icon-close {\n      position: absolute;\n      bottom: 100%;\n      left: 100%; }\n\n.icon-close {\n  cursor: pointer;\n  position: relative;\n  border: 1px solid #fff;\n  width: 20px;\n  height: 20px;\n  border-radius: 100%;\n  -webkit-transform: rotate(45deg);\n     -moz-transform: rotate(45deg);\n       -o-transform: rotate(45deg);\n          transform: rotate(45deg); }\n  .icon-close::after, .icon-close::before {\n    content: '';\n    position: absolute;\n    top: 50%;\n    left: 50%;\n    -webkit-transform: translate(-50%, -50%);\n       -moz-transform: translate(-50%, -50%);\n         -o-transform: translate(-50%, -50%);\n            transform: translate(-50%, -50%);\n    width: 1px;\n    height: 1px;\n    background: #fff; }\n  .icon-close::after {\n    width: 80%; }\n  .icon-close::before {\n    height: 80%; }\n\n.swiper-container {\n  overflow: hidden;\n  overflow: scroll;\n  height: 100%;\n  width: 100%;\n  padding-right: 200px; }\n  .swiper-container .swiper-wrapper {\n    width: 100%; }\n", ""]);

// exports


/***/ }),
/* 14 */,
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
__webpack_require__(6);
__webpack_require__(2);
__webpack_require__(8);
var ajax_1 = __webpack_require__(9);
var DomAPI_0_0_4_1 = __webpack_require__(10);
var HTML = __webpack_require__(5);
var DOMAPI = DomAPI_0_0_4_1.DomAPI.CreateByHtmlString(HTML);
new DomAPI_0_0_4_1.DomAPI('body').append(DOMAPI.getElemList());
DOMAPI.find('.part-2 video').setAttr('poster', DOMAPI.find('.part-2 > img').getAttr('src'));
DOMAPI.find('.action-rule-click').on('click', function (ev) { return new DomAPI_0_0_4_1.DomAPI('.rule-float').show(); });
DOMAPI.find('.icon-close').on('click', function (ev) { return new DomAPI_0_0_4_1.DomAPI('.rule-float').hide(); });
DOMAPI.find('.action-ajax-click').on('click', function (ev) {
    DOMAPI.find('.action-ajax-click').addClass('pointer-events-none');
    ajax_1.ajaxSend(function () { return DOMAPI.find('.action-ajax-click').removeClass('pointer-events-none'); });
});


/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * todo
 * can use Url module
 */

var a = document.createElement('a');
var a_pathname = document.createElement('a');
var __dirname__list = null;
var __dirname = null;

var __protocol = location.protocol;
var __host = location.host;
var __origin = __protocol + '//' + __host;

setDirName(location.pathname);

function dir2List(path) {
    var pathListNew = [],
        pathList = path.split('/');

    for (var i = 0, len = pathList.length - 1; i < len; i++) {
        if (pathList[i] != '') {
            pathListNew.push(pathList[i]);
        }
    }

    return pathListNew;
}
function dirList2String(pathList) {
    return '/' + pathList.join('/') + '/';
}
function setDirName(path) {
    a.href = path;
    path = a.pathname;
    __protocol = a.protocol;
    __host = a.host;
    __origin = __protocol + '//' + __host;
    __dirname__list = dir2List(path);
    __dirname = dirList2String(__dirname__list);
}

var Cache = {
    update: setDirName,
    getPath: function getPath() {
        return __dirname;
    },
    resolve: function resolve(url) {
        a_pathname.href = __origin + __dirname + url;

        var search = a_pathname.search;
        var hash = a_pathname.hash;

        return a_pathname.href;
    }
};

try {
    Cache.update(document.querySelector('[main-js]').src);
} catch (e) {
    console.error('script 缺少 main-js 属性');
}

module.exports = Cache;

/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

var path = __webpack_require__(16);module.exports = path.resolve("website_01.60c7407178491af25f7d6a04d40760bf.jpg");

/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

var path = __webpack_require__(16);module.exports = path.resolve("website_02.53bf3139f7c697f88342dd5cd57ab5f7.jpg");

/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

var path = __webpack_require__(16);module.exports = path.resolve("website_03.3ff023f927c81780a7aebc63b7918777.jpg");

/***/ })
/******/ ]);